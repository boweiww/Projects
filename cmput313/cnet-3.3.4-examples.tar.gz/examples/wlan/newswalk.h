
extern	void init_newswalk(CnetEvent ev);
extern	void start_walking(void);
extern	void stop_walking(void);
extern	bool am_walking(void);
