
extern	void init_randomwalk(CnetEvent ev);
extern	void start_walking(void);
extern	void stop_walking(void);
extern	bool am_walking(void);
