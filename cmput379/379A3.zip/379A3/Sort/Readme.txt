Acknowledgements
I used these websites for these programs:
https://en.wikipedia.org/wiki/Quicksort
https://en.wikipedia.org/wiki/Heapsort
https://en.wikipedia.org/wiki/Merge_sort
https://www.tutorialspoint.com/data_structures_algorithms/quick_sort_program_in_c.htm
https://www.tutorialspoint.com/data_structures_algorithms/merge_sort_program_in_c.htm
https://www.sanfoundry.com/c-program-heap-sort-algorithm/